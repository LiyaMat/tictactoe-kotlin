package com.example.tictactoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.collections.ArrayList

open class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun buttonclick(view: View){
        val buttonselected =view as Button
        var cellid=0
        when (buttonselected.id){
            R.id.button1->cellid=1
            R.id.button2->cellid=2
            R.id.button3->cellid=3
            R.id.button4->cellid=4
            R.id.button5->cellid=5
            R.id.button6->cellid=6
            R.id.button7->cellid=7
            R.id.button8->cellid=8
            R.id.button9->cellid=9

        }
        playgame(cellid ,buttonselected)

    }
    var activeplayer=1
    var player1=ArrayList<Int>()
    var player2=ArrayList<Int>()
  fun  playgame(cellid:Int,buttonselected:Button){
      if(activeplayer==1){
          buttonselected.text="X"
          activeplayer=2
          player1.add(cellid)
          autoplay()
      }
      else{
          buttonselected.text="O"
          activeplayer=1
          player2.add(cellid)
      }
      buttonselected.isEnabled  = false
      checkwinner()

    }
    fun checkwinner(){
        var winner=-1
        //row wise
        if(player1.contains(1)&& player1.contains(2)&& player1.contains(3)){
            winner=1
        }
        if (player2.contains(1) && player2.contains(2) && player2.contains(3)) {
            winner = 2
        }
        if (player1.contains(4) && player1.contains(5) && player1.contains(6)) {
            winner = 1
        }
        if (player2.contains(4) && player2.contains(5) && player2.contains(6)) {
            winner = 2
        }

        if (player1.contains(7) && player1.contains(8) && player1.contains(9)) {
            winner = 1
        }
        if (player2.contains(7) && player2.contains(8) && player2.contains(9)) {
            winner = 2
        }


        // column wise
        if (player1.contains(1) && player1.contains(4) && player1.contains(7)) {
            winner = 1
        }
        if (player2.contains(1) && player2.contains(4) && player2.contains(7)) {
            winner = 2
        }

        if (player1.contains(2) && player1.contains(5) && player1.contains(8)) {
            winner = 1
        }
        if (player2.contains(2) && player2.contains(5) && player2.contains(8)) {
            winner = 2
        }
        if (player1.contains(3) && player1.contains(6) && player1.contains(9)) {
            winner = 1
        }
        if (player2.contains(3) && player2.contains(6) && player2.contains(9)) {
            winner = 2
        }
        if (winner == 1) {
            var player1WinsCounts = 1
            Toast.makeText(this, "Player 1 win the game", Toast.LENGTH_LONG).show()
            restartGame()

        } else if (winner == 2) {
            var player2WinsCounts = 1
            Toast.makeText(this, "Player 2 win the game", Toast.LENGTH_LONG).show()
            restartGame()
        }

    }
    fun autoplay(){
        var emptyCells = ArrayList<Int>()

        for( cellId in 1..9){

            if( !(player1.contains(cellId) || player2.contains(cellId))){
                emptyCells.add(cellId)
            }
        }
        if(emptyCells.size==0){
            restartGame()
        }
        val r = Random()
        val randIndex = r.nextInt(emptyCells.size )
        val cellId = emptyCells[randIndex]

        var buttonselected:Button?
        buttonselected =  when(cellId){
            1-> button1
            2-> button2
            3-> button3
            4-> button4
            5-> button5
            6-> button6
            7-> button7
            8-> button8
            9-> button9
            else ->{ button1}

        }

        playgame(cellId, buttonselected)

    }
    var player1WinsCounts = 0
    var player2WinsCounts = 0

    fun restartGame(){

        activeplayer = 1
        player1.clear()
        player2.clear()

        for(cellId in 1..9){

            var buttonselected:Button? = when(cellId){
                1-> button1
                2-> button2
                3-> button3
                4-> button4
                5-> button5
                6-> button6
                7-> button7
                8-> button8
                9-> button9
                else ->{ button1}

            }
            buttonselected!!.text=""

            buttonselected!!.isEnabled = true
        }

        Toast.makeText(this,"Player1: $player1WinsCounts, Player2: $player2WinsCounts", Toast.LENGTH_LONG).show()



    }

}